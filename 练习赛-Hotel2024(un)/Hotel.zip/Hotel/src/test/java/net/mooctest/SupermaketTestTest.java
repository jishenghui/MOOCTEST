package net.mooctest;

import org.junit.Before;

import static org.junit.Assert.*;

public class SupermaketTestTest {

    @Before
    public void setUp() throws Exception {

    }
}