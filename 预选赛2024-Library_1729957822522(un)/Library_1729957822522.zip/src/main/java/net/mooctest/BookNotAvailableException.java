package net.mooctest;

public class BookNotAvailableException extends Exception{
        public BookNotAvailableException(String message) {
            super(message);
        }
    }
