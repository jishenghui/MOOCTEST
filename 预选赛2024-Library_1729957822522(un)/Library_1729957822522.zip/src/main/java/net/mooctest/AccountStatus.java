package net.mooctest;

public enum AccountStatus {
    ACTIVE,
    FROZEN,
    BLACKLISTED
}
