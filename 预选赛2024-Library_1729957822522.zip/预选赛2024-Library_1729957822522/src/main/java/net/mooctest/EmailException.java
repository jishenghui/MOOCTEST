package net.mooctest;

public class EmailException extends Exception{
        public EmailException(String message) {
            super(message);
        }
    }
