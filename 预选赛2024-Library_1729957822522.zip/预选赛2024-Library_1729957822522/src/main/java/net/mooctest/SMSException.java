package net.mooctest;

public class SMSException extends Exception{
        public SMSException(String message) {
            super(message);
        }
    }
