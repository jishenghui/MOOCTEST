package net.mooctest;

public class OverdueFineException extends Exception{
        public OverdueFineException(String message) {
            super(message);
        }
    }
