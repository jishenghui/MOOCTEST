package net.mooctest;

public enum BookType {
    GENERAL,
    RARE,
    JOURNAL,
    EBOOK
}
