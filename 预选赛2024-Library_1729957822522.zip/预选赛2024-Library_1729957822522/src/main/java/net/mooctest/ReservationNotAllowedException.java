package net.mooctest;

public class ReservationNotAllowedException extends Exception{
        public ReservationNotAllowedException(String message) {
            super(message);
        }
    }
