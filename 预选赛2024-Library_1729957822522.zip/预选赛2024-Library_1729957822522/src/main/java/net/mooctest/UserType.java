package net.mooctest;

public enum UserType {
    REGULAR,
    VIP,
    STUDENT,
    TEACHER,
    LIBRARIAN
}
