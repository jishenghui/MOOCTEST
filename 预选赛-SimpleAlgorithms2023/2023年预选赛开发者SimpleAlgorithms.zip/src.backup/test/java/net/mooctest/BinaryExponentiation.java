package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class BinaryExponentiationTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
