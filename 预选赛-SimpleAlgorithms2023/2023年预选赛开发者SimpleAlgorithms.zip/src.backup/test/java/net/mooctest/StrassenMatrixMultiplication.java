package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class StrassenMatrixMultiplicationTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
