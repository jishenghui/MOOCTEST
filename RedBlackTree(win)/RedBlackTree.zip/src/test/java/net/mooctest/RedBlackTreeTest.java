package net.mooctest;

import org.junit.Assert;
import org.junit.Test;

public class RedBlackTreeTest {
    
    @Test
    public void testInsert() {
        RedBlackTree tree = new RedBlackTree();
    }

}
