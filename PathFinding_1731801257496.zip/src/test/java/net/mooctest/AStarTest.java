package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/*
 * 测试代码基于JUnit 4，若eclipse提示未找到Junit 5的测试用例，请在Run Configurations中设置Test Runner为Junit 4。请不要使用Junit 5
 * 语法编写测试代码
 */

public class AStarTest {

    @Test
    public void testSearch_WithNoObstacles_ShouldReturnPath() {
    	AStar astar = new AStar();
    	        
    }

}
