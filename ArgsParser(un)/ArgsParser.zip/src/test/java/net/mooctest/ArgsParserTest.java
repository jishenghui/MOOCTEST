package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArgsParserTest {

	@Test
	public void test() {
//		fail("Not yet implemented");
	}

}
