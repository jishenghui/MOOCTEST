package net.mooctest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;


public class MoreTriangleTest{

  @Test(timeout = 4000)
  public void test00() {
      MoreTriangle moreTriangle = new MoreTriangle(0, 0, 0, 0, 0, 0);
  }
}
